/**
 * 
 */
/**
 * 
 */
module Ejemplo08_Clases_Abstractas {
}