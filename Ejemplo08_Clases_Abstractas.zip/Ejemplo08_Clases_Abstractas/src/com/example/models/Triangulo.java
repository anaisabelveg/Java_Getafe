package com.example.models;

public class Triangulo extends Rectangulo{
	
	public Triangulo() {
		// TODO Auto-generated constructor stub
	}

	public Triangulo(int x, int y, int base, int altura) {
		super(x, y, base, altura);
	}

	@Override
	public double calcularArea() {
		// base * altura / 2
		return super.calcularArea() / 2;
	}
	
}
