package com.example.models;

public class Circulo extends Figura{
	
	private int radio;
	
	public Circulo() {
		// TODO Auto-generated constructor stub
	}

	public Circulo(int x, int y, int radio) {
		super(x, y);
		this.radio = radio;
	}
	
	@Override
	public double calcularArea() {
		// PI * radio al cuadrado
		return Math.PI * Math.pow(radio, 2);
	}

	public int getRadio() {
		return radio;
	}

	public void setRadio(int radio) {
		this.radio = radio;
	}

}
