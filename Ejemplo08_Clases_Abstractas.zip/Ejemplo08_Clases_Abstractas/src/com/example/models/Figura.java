package com.example.models;

// Si la clase tiene un metodo abstracto, hay que declararla como abstracta
// Una clase abstracta tiene metodo implemntados y otros abstractos (clase inacabada)
// Una clase abstracta sirve como tipo de datos, pero no puedo crear un objeto de ella
public abstract class Figura {
	
	private int x;
	private int y;
	
	// Contructor vacio, completo, getter y setter y toString
	public Figura() {
		// TODO Auto-generated constructor stub
	}

	public Figura(int x, int y) {
		super();
		this.x = x;
		this.y = y;
	}
	
	// Declarar el metodo pero no lo implementamos  (Metodo abstracto)
	public abstract double calcularArea();  // si {} esta implementado

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}

	@Override
	public String toString() {
		return "[" + x + "," + y + "]";
	}
	
}
