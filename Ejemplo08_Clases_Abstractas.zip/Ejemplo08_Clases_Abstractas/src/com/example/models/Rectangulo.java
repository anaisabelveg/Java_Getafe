package com.example.models;

public class Rectangulo extends Figura{
	
	private int base;
	private int altura;
	
	// Constructor vacio, constructor completo, getter y setter y toString
	public Rectangulo() {
		// TODO Auto-generated constructor stub
	}

	public Rectangulo(int x, int y, int base, int altura) {
		super(x, y);
		this.base = base;
		this.altura = altura;
	}

	@Override
	public double calcularArea() {
		return base * altura;
	}
	
	public int getBase() {
		return base;
	}

	public void setBase(int base) {
		this.base = base;
	}

	public int getAltura() {
		return altura;
	}

	public void setAltura(int altura) {
		this.altura = altura;
	}

	@Override
	public String toString() {
		return super.toString() + ", base=" + base + ", altura=" + altura;
	}

	
	
	

}
