package com.example;

import com.example.models.Circulo;
import com.example.models.Figura;
// ctrl + shift + o
import com.example.models.Rectangulo;
import com.example.models.Triangulo;

public class AppMain {

	public static void main(String[] args) {
		Rectangulo rectangulo = new Rectangulo(10, 20, 120, 70);
		System.out.println("Area del rectangulo: " + rectangulo.calcularArea());
		
		Triangulo triangulo = new Triangulo(10, 20, 120, 70);
		System.out.println("Area del triangulo: " + triangulo.calcularArea());
		
		Circulo circulo = new Circulo(10, 20, 36);
		System.out.println("Area del circulo: " + circulo.calcularArea());
		
		// Puedo crear una variable de tipo figura
		Figura figura;
		
		// Al ser la clase abstracta no puedo instanciar Figura
		//figura = new Figura();
		
	}

}
