/**
 * 
 */
/**
 * 
 */
module Ejemplo06_Herencia {
}