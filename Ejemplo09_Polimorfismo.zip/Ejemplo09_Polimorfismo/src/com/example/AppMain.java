package com.example;

import com.example.models.Empleado;
import com.example.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		
		// anaisabelveg@gmail.com
		
		// Polimorfismo es la capacidad de ver el mismo objeto de multiples formas
		// EL OBJETO NO CAMBIA, solo la forma de verlo
		
		Empleado empleado = new Empleado("Laura", 28, 45000);
		// Tenemos visibilidad total del objeto
		empleado.getNombre();
		empleado.getEdad();
		empleado.getSueldo();
		empleado.toString();
		
		// Solo tengo visibilidad de los recursos de Persona y Object
		Persona persona = new Empleado("Laura", 28, 45000);
		persona.getNombre();
		persona.getEdad();
		// persona.getSueldo();  NO tengo visibilidad
		persona.toString();
		
		// Solo tengo visibilidad de los recursos de Object
		Object object = new Empleado("Laura", 28, 45000);
		//object.getNombre();  NO tengo visibilidad
		//object.getEdad();   NO tengo visibilidad
		// persona.getSueldo();  NO tengo visibilidad
		object.toString();
		
		// Cambiar la visibilidad del objeto
		// Es el tipo de la variable quien decide como se ve el objeto
		Persona p = (Persona) object;
		Empleado e = (Empleado) object;
		Empleado e2 = (Empleado) p;
	}

}














