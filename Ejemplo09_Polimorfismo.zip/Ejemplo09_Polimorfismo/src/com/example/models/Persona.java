package com.example.models;

import java.util.Objects;

// El compilador si ve que la clase no hereda de ninguna otra
// añade extends Object
//public class Persona extends Object{
public class Persona {

	private String nombre;
	private int edad;

	// El compilador en el momento de la compilacion
	// mira si hay algun constructor declarado en la clase
	// si no hay ninguno, añade el constructor por defecto
	// sin argumentos
	// Buena practica es tener siempre el constructor por defecto.
	// Si agregamos otro, este lo hacemos explicito porque el
	// compilador no lo va a añadir
	public Persona() {
		// TODO Auto-generated constructor stub
	}

	// Java permite crear varios constructores (Sobrecarga de constructores)
	public Persona(String nombre, int edad) {
		super();
		this.nombre = nombre;
		this.edad = edad;
	}

	// sobreescribir un metodo heredado
	@Override
	public String toString() {
		// retorna la informacion textual del objeto
		return "nombre=" + nombre + ", edad=" + edad;
	}
	
	

	@Override
	public int hashCode() {
		return Objects.hash(Integer.valueOf(edad), nombre);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)   // this y obj es el mismo objeto, misma referencia
			return true;
		if (obj == null)   // No existe el objeto obj
			return false;
		if (getClass() != obj.getClass())  // las clases de los objetos son distintas
			return false;
		Persona other = (Persona) obj;   // Convierte obj a Persona
		return edad == other.edad && Objects.equals(nombre, other.nombre);
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

}
