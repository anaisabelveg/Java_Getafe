package com.example.models;

import java.util.Objects;

// Crear la clase Empleado heredando de la clase Persona
// Los recursos privados y estaticos no se heredan
public class Empleado extends Persona {

	// Propiedades
	private double sueldo;

	// Constructores
	public Empleado() {
		// Siempre que hay una herencia, el constructor tiene super() implicita
		super(); // llama al constructor por defecto de la superclase Persona
	}

	public Empleado(String nombre, int edad, double sueldo) {
		// llama al constructor de la superclase pasandole el nombre y la edad
		super(nombre, edad); // siempre ha de ser la primera linea en el constructor
		this.sueldo = sueldo;
	}

	// Metodos
	@Override
	public String toString() {
		// super.toString() llama al metodo toString de la superclase
		return super.toString() + ", sueldo=" + sueldo;
	}
	
	

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(sueldo);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empleado other = (Empleado) obj;
		return Double.doubleToLongBits(sueldo) == Double.doubleToLongBits(other.sueldo);
	}

	public double getSueldo() {
		return sueldo;
	}

	public void setSueldo(double sueldo) {
		// El puntero this. apunta a la propia instancia
		// Solo ve los recursos de instancia (propiedades y metodos)
		this.sueldo = sueldo;
	}

}
