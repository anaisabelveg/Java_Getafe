package com.example;

import java.util.Scanner;

public class AdivinarNumero {

	public static void main(String[] args) {
		// generar un numero aleatorio entre 1 y 10
		// adivinar el numero dando pista
		// solo tenga 5 intentos
		int numero = ((int) (Math.random() * 10)) + 1;
		//System.out.println(numero);
		
		Scanner scanner = new Scanner(System.in);
		int prueba = 0;
		int contador = 0;
		do {
			System.out.println("Adivina numero del 1 al 10: ");
			prueba = scanner.nextInt();
			contador++;
			
			if (prueba > numero) {
				System.out.println("Prueba un numero menor");
				System.out.println("Te quedan " + (5 - contador) + " intentos");
			} else if (prueba < numero) {
				System.out.println("Prueba un numero mayor");
				System.out.println("Te quedan " + (5 - contador) + " intentos");
			}
			
		} while((prueba != numero) && (contador < 5));
		
		if (prueba == numero)
			System.out.println("Acertaste !!!");
		else
			System.out.println("Se acabaron los intentos");

	}

}
