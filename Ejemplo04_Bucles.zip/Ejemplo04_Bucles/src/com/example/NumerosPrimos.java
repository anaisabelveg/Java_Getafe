package com.example;

public class NumerosPrimos {
	
	public static void main(String[] args) {
		// Un numero primo solo es divisible por si mismo y por 1
		// Partir de una variable booleana esPrimo = true
		// Mostrar los numeros primos del 1 al 100
		
		// Etiqueta para nombrar el bucle
		numeros:
		for (int num = 1; num <= 100; num++) {
			boolean esPrimo = true;
			System.out.println("Probando si el numero " + num + " es primo");
			
			for(int divisor = 2; divisor < num; divisor++) {
				System.out.println("Probando divisor " + divisor);
				if (num % divisor == 0) {
					esPrimo = false;
					// Damos por terminado el bucle
					//break;
					
					// Damos por terminada es esta iteracion, esta vuelta
					continue numeros;
				}
			}
			
			if (esPrimo) System.out.println(num);
		}
		
	}

}
