package com.example;

public class ArraysForEach {
	
	public static void main(String[] args) {
		//int num = 8;
		int numeros[] = {7,9,2,4,3,8};
		
		// Mostrar la suma de todos los numeros del array
		int suma = 0;
		for (int num : numeros) {
			suma += num;   // suma = suma + num;
		}
		System.out.println("Resultado: " + suma);
		
		String nombres[] = {"Luis", "Maria", "Juan"};
		String apellidos[] = {"Perez", "Lopez", "Rodriguez"};
		
		for(int idx=0; idx < nombres.length; idx++) {
			System.out.println(nombres[idx] + " " + apellidos[idx]);
		}
	}

}
