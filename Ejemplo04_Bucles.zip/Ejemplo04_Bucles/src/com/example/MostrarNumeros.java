package com.example;

public class MostrarNumeros {

	public static void main(String[] args) {
		
		// mostrar los numeros del 1 al 10
		int num = 1;
		for(num = 1; num <= 10; num += 1) {
			System.out.println(num);
		}
		System.out.println("----------------------");
		
		// mostrar los numeros del 0 al 10 de 2 en 2
		for(num = 0; num <= 10; num += 2) {
			System.out.println(num);
		}
		System.out.println("----------------------");
		
		// mostrar los numeros del 10 al 1
		for(num = 10; num >= 1; num-=1) {
			System.out.println(num);
		}
		System.out.println("----------------------");
		
		// mostrar los numeros del 1 al 10 pero solo los multiplos de 3
		for(num = 1; num <= 10; num += 1) {
			if (num % 3 == 0)
				System.out.println(num);
		}
		System.out.println("----------------------");

	}

}
