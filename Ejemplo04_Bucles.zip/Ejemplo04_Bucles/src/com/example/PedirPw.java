package com.example;

import java.util.Scanner;

public class PedirPw {

	public static void main(String[] args) {
		// Solicitar el pw al usuario hasta que acierte "curso"
		Scanner scanner = new Scanner(System.in);
		
		/*
		while(condicion) {
			
		}
		
		do {
			
		}while(condicion);
		*/
		String pw = "";
		do {
			System.out.println("Introduce PW: ");
			pw = scanner.next();
			
		}while(!"curso".equals(pw));
		
		System.out.println("PW correcta");

	}

}
