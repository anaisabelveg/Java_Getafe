package com.example;

public class TablasMultiplicar {

	public static void main(String[] args) {
		// Crear un bucle para las tablas del 1 al 10
		// dentro otro bucle para recorrer los numeros del 1 al 10
		for (int tabla = 1; tabla <= 10; tabla++) {
			System.out.println("Tabla del numero " + tabla);
			
			for (int num = 1; num <= 10; num++) {
				System.out.println(tabla + " x " + num + " = " + (tabla * num));
			}
			System.out.println();  // Provoca un salto de linea
		}

	}

}
