package com.example;

public class ArraysWhile {
	
	public static void main(String[] args) {
		
		int numeros[] = {7,9,2,4,3,8};
		
		// Mostrar la suma de todos los numeros del array
		int suma = 0;
		int idx = 0;
		while(idx < numeros.length) {
			suma = suma + numeros[idx]; // suma += numeros[idx];
			idx++;
		}
		
		System.out.println("Resultado: " + suma);
			
	}

}
