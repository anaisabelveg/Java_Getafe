package com.example;

import java.util.Scanner;

public class DiaSemana {

	public static void main(String[] args) {
		// con if anidados, solicitar una letra mayuscula o miniscula al usuario
		// y mostrar a que dia de la semana pertenece
		Scanner scanner = new Scanner(System.in);
		System.out.println("Introduce letra del dia de la semana: ");
		String letra = scanner.next();
		
		if ("l".equals(letra) || "L".equals(letra))
			System.out.println("Es lunes");
		else if ("m".equals(letra) || "M".equals(letra))
			System.out.println("Es martes");
		else if ("x".equals(letra) || "X".equals(letra))
			System.out.println("Es miercoles");
		else if ("j".equals(letra) || "J".equals(letra))
			System.out.println("Es jueves");
		else if ("v".equals(letra) || "V".equals(letra))
			System.out.println("Es viernes");
		else if ("s".equals(letra) || "S".equals(letra))
			System.out.println("Es sabado");
		else if ("d".equals(letra) || "D".equals(letra))
			System.out.println("Es domingo");
		else
			System.out.println("Dia no valido");
	}

}
