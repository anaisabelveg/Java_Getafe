package com.example;

import java.util.Scanner;

public class ParImpar {

	public static void main(String[] args) {
		// System.in -> Teclado
		// System.out -> Consola
		Scanner scanner = new Scanner(System.in);
		System.out.println("Introduce un numero: ");
		//System.out.println(scanner.next());   // next() retorna un String
		int numero = scanner.nextInt();  // nextInt() lo convierte a numero entero
		
		// Mostrar si es par o impar y si es mayor que 10 o no
		if ((numero % 2 == 0) && (numero > 10)) {
			System.out.println("El numero " + numero + " es par y mayor que 10");
		} else if ((numero % 2 != 0) && (numero > 10)){
			System.out.println("El numero " + numero + " es impar y mayor que 10");
		} else if ((numero % 2 == 0) && (numero < 10)) {
			System.out.println("El numero " + numero + " es par y menor que 10");
		} else if ((numero % 2 != 0) && (numero < 10)) {
			System.out.println("El numero " + numero + " es impar y menor que 10");
		} else {
			System.out.println("El numero " + numero + " es par e igual 10");
		} 

	}

}
