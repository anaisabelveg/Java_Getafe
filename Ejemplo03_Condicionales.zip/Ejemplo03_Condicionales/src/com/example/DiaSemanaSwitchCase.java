package com.example;

import java.util.Scanner;

public class DiaSemanaSwitchCase {

	public static void main(String[] args) {
		// con if anidados, solicitar una letra mayuscula o miniscula al usuario
		// y mostrar a que dia de la semana pertenece
		Scanner scanner = new Scanner(System.in);
		System.out.println("Introduce letra del dia de la semana: ");
		String letra = scanner.next();
		
		// Necesitamos una expresion
		switch (letra) {
			case "l":
			case "L":
				System.out.println("Es lunes");
				break;  // Es optativo
			case "m":
			case "M":
				System.out.println("Es martes");
				break;
			case "x":
			case "X":
				System.out.println("Es miercoles");
				break;
			case "j":
			case "J":
				System.out.println("Es jueves");
				break;
			case "v":
			case "V":
				System.out.println("Es viernes");
				break;
			case "s":
			case "S":
				System.out.println("Es sabado");
				break;
			case "d":
			case "D":
				System.out.println("Es domingo");
				break;
			default:
				System.out.println("Dia no valido");
		}	

	}

}
