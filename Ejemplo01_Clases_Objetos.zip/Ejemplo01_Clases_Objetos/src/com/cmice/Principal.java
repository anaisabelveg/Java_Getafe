package com.cmice;

// En Java, siempre que utilizo un recurso que esta en otro paquete hay que importarlo
import com.cmice.models.Cliente;

public class Principal {

	// Hace que esta clase sea la puerta de entrada a la aplicacion
	public static void main(String... pepito) {
		// Crear un objeto de tipo Cliente
		Cliente cliente1 = new Cliente();
		
		// Personalizar el objeto
		cliente1.nombre = "Transportes Lopez";
		cliente1.cif = "B-12345678";
		cliente1.vip = false;
		cliente1.importeCompras = 5677754.455;
		
		// Mostrar la informacion del objeto
		cliente1.mostrarInfo();

	}

}
