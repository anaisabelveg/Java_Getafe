package com.cmice.models;

public class Cliente {
	
	// caracteristicas, atributos, que diferencian un cliente de otro
	// propiedades o campos
	public String nombre;
	public String cif;
	public boolean vip;
	public double importeCompras;
	
	// metodos
	public void mostrarInfo() {
		// cuerpo del metodo
		// Todo lo que pongas dentro de los parentesis te lo muestra en la consola
		System.out.println("Nombre: " + nombre + ", CIF: " + cif + 
				", VIP: " + vip + ", importe de compras: " + importeCompras);
	}

}
