package com.example;

import com.example.models.Pajaro;
import com.example.models.Perro;

public class AppMain {

	public static void main(String[] args) {
		Pajaro pajaro = new Pajaro(1, 'M', false, true);
		System.out.println(pajaro);
		
		Pajaro pajaro2 = new Pajaro(1, 'M', false, true);
		System.out.println(pajaro.equals(pajaro2));
		
		Perro perro = new Perro(2, 'H', true, "Caniche");
		System.out.println(perro);
		
		Perro perro2 = new Perro(2, 'H', true, "Caniche");
		System.out.println(perro.equals(perro2));

	}

}
