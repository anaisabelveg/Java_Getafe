package com.example.models;

import java.util.Objects;

public class Pajaro extends Animal {

	// 1.- Propiedades
	private boolean exotico;

	// 2.- Constructores
	public Pajaro() {
		// TODO Auto-generated constructor stub
	}

	public Pajaro(int edad, char sexo, boolean vacunado, boolean exotico) {
		super(edad, sexo, vacunado);
		this.exotico = exotico;
	}

	// 3.- Metodos ordenados por los mas relevantes primero
	@Override
	public String toString() {
		return super.toString() + ", exotico=" + exotico;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(exotico);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Pajaro other = (Pajaro) obj;
		return exotico == other.exotico;
	}

	// Con propiedades booleanas no tenemos un getExotico
	public boolean isExotico() {
		return exotico;
	}

	public void setExotico(boolean exotico) {
		this.exotico = exotico;
	}

}
