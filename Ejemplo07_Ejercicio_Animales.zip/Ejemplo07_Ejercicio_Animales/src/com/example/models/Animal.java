package com.example.models;

import java.util.Objects;

// Si mi clase no hereda de ninguna otra, el compilador añade extends Object
public class Animal {

	// propiedades
	// constructor vacio ctrl + space
	// constructor completo bton dcho + source + generate constructor using fields
	// getter y setter bton dcho + source + generate getters and setters
	// toString bton dcho + source + generate toString
	// equals y hashCode bton dcho + source + generate equals y hashcode

	private int edad;
	private char sexo;
	private boolean vacunado;

	// Java soporta sobrecarga de constructores
	// esto significa que puedes tener mas de un constructor por clase
	// asi que nos da un abanico de posibilidades a la hora de crear el objeto
	public Animal() {
		// TODO Auto-generated constructor stub
	}

	public Animal(int edad, char sexo, boolean vacunado) {
		super();
		this.edad = edad;
		this.sexo = sexo;
		this.vacunado = vacunado;
	}

	@Override
	public String toString() {
		return "edad=" + edad + ", sexo=" + sexo + ", vacunado=" + vacunado;
	}

	@Override
	public int hashCode() {
		return Objects.hash(Integer.valueOf(edad), Character.valueOf(sexo), Boolean.valueOf(vacunado));
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Animal other = (Animal) obj;  // Polimorfismo
		return edad == other.edad && sexo == other.sexo && vacunado == other.vacunado;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}

	public char getSexo() {
		return sexo;
	}

	public void setSexo(char sexo) {
		this.sexo = sexo;
	}

	public boolean isVacunado() {
		return vacunado;
	}

	public void setVacunado(boolean vacunado) {
		this.vacunado = vacunado;
	}

}
