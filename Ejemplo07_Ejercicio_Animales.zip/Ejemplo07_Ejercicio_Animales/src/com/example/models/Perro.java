package com.example.models;

import java.util.Objects;

public class Perro extends Animal {

	private String raza;

	public Perro() {
		// TODO Auto-generated constructor stub
	}

	public Perro(int edad, char sexo, boolean vacunado, String raza) {
		// Llama al constructor de la superclase
		super(edad, sexo, vacunado);
		this.raza = raza;
	}

	@Override
	public String toString() {
		return super.toString() + ", raza=" + raza;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + Objects.hash(raza);
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Perro other = (Perro) obj;
		return Objects.equals(raza, other.raza);
	}

	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}

}
