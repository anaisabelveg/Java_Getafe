/**
 * 
 */
/**
 * 
 */
module Ejemplo05_Encapsulacion {
}