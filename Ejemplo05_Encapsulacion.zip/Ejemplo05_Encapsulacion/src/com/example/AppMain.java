package com.example;

import com.example.models.Fecha;
import com.example.models.FechaEncapsulada;

public class AppMain {

	public static void main(String[] args) {
		Fecha fecha = new Fecha();
		fecha.dia = 227654;
		fecha.mes = -233;
		fecha.anyo = 0;
		fecha.mostrarFecha();
		
		FechaEncapsulada fechaBuena = new FechaEncapsulada();
		//fechaBuena.dia = 15; no puedo acceder a un recurso privado
		fechaBuena.setDia(227654);
		fechaBuena.setMes(-233);
		fechaBuena.setAnyo(0);
		fechaBuena.mostrarFecha();
		

		fechaBuena.setDia(22);
		fechaBuena.setMes(10);
		fechaBuena.setAnyo(2026);
		fechaBuena.mostrarFecha();

	}

}
