package com.example.models;

public class Fecha {
	
	// un recurso publico es accesible desde cualquier clase de la aplicacion 
	public int dia;
	public int mes;
	public int anyo;
	
	public void mostrarFecha() {
		System.out.println(dia + "/" + mes + "/" + anyo);
	}

}
