package com.example.models;


// Una clase encapsulada, define todas sus propiedades como privadas
// y se accede a ellas a través de métodos get y set publicos
public class FechaEncapsulada {
	
	// un recurso private es accesible unicamente desde dentro de la clase 
	private int dia;
	private int mes;
	private int anyo;
	
	public void mostrarFecha() {
		System.out.println(dia + "/" + mes + "/" + anyo);
	}

	// Metodo de lectura -> retorna el valor de la propiedad
	public int getDia() {
		return dia;
	}

	// Metodo de escritura -> asigna el valor a la propiedad
	public void setDia(int dia) {
		if (dia > 0 && dia <= 31) 
			this.dia = dia;
		else
			System.out.println("Dia no valido");
	}

	public int getMes() {
		return mes;
	}

	public void setMes(int mes) {
		if (mes > 0 && mes <= 12)
			this.mes = mes;
		else
			System.out.println("Mes no valido");
	}

	public int getAnyo() {
		return anyo;
	}

	public void setAnyo(int anyo) {
		if (anyo == 2026 || anyo == 2027)
			this.anyo = anyo;
		else
			System.out.println("Año no valido");
	}
	
	

}
