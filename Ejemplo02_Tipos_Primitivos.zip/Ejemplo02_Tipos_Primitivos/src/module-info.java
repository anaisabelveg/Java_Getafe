/**
 * 
 */
/**
 * 
 */
module Ejemplo02_Tipos_Primitivos {
}