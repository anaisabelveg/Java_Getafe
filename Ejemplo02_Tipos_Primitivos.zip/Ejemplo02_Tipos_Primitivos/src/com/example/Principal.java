package com.example;

public class Principal {
	
	public static void main(String[] args) {
		/*
		  Comentario de bloque
		  que abarca varias lineas
		*/
		
		/*
		 * Comentarios de bloque
		 * que se utilizan para
		 * generar la documentacion del proyecto
		 * */
		
		// comentario de una sola linea
		// numericos enteros
		byte numByte = (byte)12;     // 8 digitos binarios
		short numShort = (short) 45566;  // 16 digitos binarios
		int numInt = 654_321;       // 32 digitos binarios  representacion por defecto
		long numLong = 456_799_987_765L;	  // 64 digitos binarios  (L o l)
		
		System.out.println(numShort);
		System.out.println(numByte);
		
		// numericos reales
		float numFloat = 3.14F;        // 32 digitos binarios  (F o f)
		double numDouble = 3.14;      // 64 digitos binarios   representacion por defecto
		
		// texto
		char letra = 'a';   // solo un caracter y entre comillas simples
		char simbolo = '\u03A6';
		System.out.println(simbolo);
		
		// booleanos
		boolean incidencia = true;    // solo true o false sin comillas
		
		// String es una clase, no es un tipo primitivo. Siempre con comillas dobles
		String saludo = "Bienvenidos al curso de Java";
		String saludo3 = "Bienvenidos al curso de Java";   // No crea objeto nuevo, sino que lo reutiliza
		// Fuerza la creacion de un nuevo objeto aunque exista otro igual
		String saludo2 = new String("Bienvenidos al curso de Java"); 
		
		// Mostrar el texto en mayusculas
		
		// Mostrar el texto en minusculas
		
		// Mostrar solo la primera palabra
		
		// Mostrar la ultima palabra
		
		// Mostrar el indice donde esta la letra J
		
		// Mostrar la palabra curso
		
		// Mostrar la longitud de la cadena
		
	}

}












