package com.example;

import com.example.models.Empleado;
import com.example.models.Persona;

public class AppMain {

	public static void main(String[] args) {
		
		// Clase variable = operador_new constructor_de_Persona();
		Persona persona = new Persona();
		persona.setNombre("Juan");
		persona.setEdad(27);
			
		Persona persona2 = new Persona("Maria", 35);
		
		Empleado empleado = new Empleado();
		empleado.setNombre("Laura");
		empleado.setEdad(28);
		empleado.setSueldo(45000);
		
		Empleado empleado2 = new Empleado("Laura", 28, 45000);
		
		// syso + ctrl + space
		System.out.println(persona);
		// com.example.models.Persona@2dda6444       paquete.nombre@hashcode
		System.out.println(empleado);
		
		int num1 = 7;
		int num2 = 7;
		// con == se comparan el contenido de las variables (funciona con tipos primitivos)
		System.out.println("Son iguales? " + (num1 == num2));
		// Con los objetos no funciona
		System.out.println("Son iguales los empleados? " + (empleado == empleado2));
		
		// Los objetos, el contenido de los objetos se compara con equals
		System.out.println("Son iguales los empleados? " + (empleado.equals(empleado2)));

	}

}














